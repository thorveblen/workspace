import javax.swing.JOptionPane;

// J Flannery 8 14 2024   first in class exercise module 1

public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("A lady who is warm and human during the day");// great code
		System.out.println("A classy lady who knows how to enjoy a cup of coffee");
		//JOptionPane.showMessageDialog(null, "Gangnan style");
		JOptionPane.showMessageDialog(null, "Shown on the screen");

	}

}

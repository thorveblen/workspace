// name date purpose
public class Something {

	public static void main(String[] args) {
		System.out.println("Useless");

	}

}
